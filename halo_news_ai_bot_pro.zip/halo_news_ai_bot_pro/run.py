from halo_news_bot.cli import main

if __name__ == "__main__":
    raise SystemExit(main())
